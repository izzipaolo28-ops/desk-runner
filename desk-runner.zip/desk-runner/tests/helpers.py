"""Shared fakes for the desk-runner tests: a scripted network, a fake desk built on the real questions.py, and a
temporary book. Nothing here touches the real network."""
import os
import sys
import tempfile
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(ROOT), str(Path(__file__).resolve().parent)]
os.environ.setdefault("DESK_DB", os.path.join(tempfile.mkdtemp(), "desk.db"))
os.environ.setdefault("DATA_DIR", tempfile.mkdtemp())
os.environ.setdefault("DESK_SECRET", "s" * 40)
os.environ.setdefault("JUDGE_URL", "http://127.0.0.1:8081")
os.environ.setdefault("JUDGE_LOG", os.path.join(tempfile.mkdtemp(), "judge_log.jsonl"))

import typesafe_sdk_shim  # noqa: E402

sys.modules.setdefault("typesafe_sdk", typesafe_sdk_shim)

import collect  # noqa: E402
import questions  # noqa: E402

SOL_TOKEN = "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"
EVM_TOKEN = "0x" + "ab" * 20


class Resp:
    def __init__(self, body=None, status=200):
        self.body, self.status_code, self.headers = body, status, {}

    def json(self):
        if isinstance(self.body, Exception):
            raise self.body
        return self.body


class Net:
    """Routes fake responses by URL substring (GET) or JSON-RPC method (POST); records every call."""

    def __init__(self, monkeypatch):
        self.calls, self.get_routes, self.rpc = [], {}, {}
        monkeypatch.setattr(collect.time, "sleep", lambda s: self.calls.append(("sleep", s)))
        monkeypatch.setattr(collect.HTTP, "get", self._get)
        monkeypatch.setattr(collect.HTTP, "post", self._post)
        monkeypatch.setattr(collect, "GT_LIMIT", collect._Limiter(1000))

    def _get(self, url, params=None, headers=None, timeout=None):
        self.calls.append(("GET", url))
        for part, resp in self.get_routes.items():
            if part in url:
                return resp.pop(0) if isinstance(resp, list) else resp
        return Resp(None, 404)

    def _post(self, url, json=None, timeout=None):
        self.calls.append(("RPC", json["method"]))
        resp = self.rpc.get(json["method"], Resp({"error": {"code": -1}}))
        return resp.pop(0) if isinstance(resp, list) else resp

    def gets(self, part=""):
        return [c for c in self.calls if c[0] == "GET" and part in c[1]]


def wire(qs):
    return {name: q.wire() for name, q in qs.items()}


class FakeDesk:
    """Builds the requested set with the real questions.py (unknown set or bad state -> 422, like the desk)
    and answers each question from a script: answers[set][question] -> answer dict."""

    def __init__(self, answers=None, model="jev-1.13.0"):
        self.answers, self.model, self.calls = answers or {}, model, []

    def __call__(self, question_set, state):
        self.calls.append((question_set, state))
        if question_set not in questions.SETS:
            raise JudgeErr(f"desk rejected {question_set} (422)", 422)
        qs = questions.SETS[question_set]
        try:
            qs = qs(state) if callable(qs) else qs
        except ValueError as exc:
            raise JudgeErr(f"desk rejected {question_set} (422): {exc}", 422) from None
        script = self.answers.get(question_set, {})
        out = {}
        for name, q in qs.items():
            a = script.get(name, default_answer(q))
            if a is not None:
                out[name] = a(state) if callable(a) else a
        return {"model": self.model, "answers": out, "usage": {"input_tokens": 300, "output_tokens": 20}}


class JudgeErr(RuntimeError):
    def __init__(self, msg, status=None):
        super().__init__(msg)
        self.status = status


def default_answer(q):
    kind = type(q).__name__
    if kind == "Noul":
        return {"type": "noul", "noul": 0.2, "confidence": 0.8}
    if kind == "Score":
        return {"type": "score", "score": 2.0, "confidence": 0.8}
    first = next(iter(q.criteria))
    probs = {k: (0.9 if k == first else 0.1 / max(1, len(q.criteria) - 1)) for k in q.criteria}
    return {"type": "choice", "choice": first, "confidence": 0.9, "probabilities": probs}


GOOD = {   # answers that pass every SOFT gate
    "market": {"shape": {"type": "choice", "choice": "crowd", "confidence": 0.9,
                         "probabilities": {"crowd": 0.9, "one_buyer": 0.05, "fading": 0.03, "too_early": 0.02}},
               "liquidity_fits_ticket": {"type": "noul", "noul": 0.9},
               "momentum_already_spent": {"type": "noul", "noul": 0.2}},
    "solana": {"authority_risk": {"type": "choice", "choice": "renounced", "confidence": 0.95},
               "concentration_is_exit_risk": {"type": "noul", "noul": 0.1},
               "dev_still_loaded": {"type": "noul", "noul": 0.1}},
    "bsc": {"sell_side_risk": {"type": "choice", "choice": "clean", "confidence": 0.9},
            "concentration_is_exit_risk": {"type": "noul", "noul": 0.1},
            "pool_quality": {"type": "score", "score": 1.5}},
    "robinhood": {"data_coverage": {"type": "choice", "choice": "partial", "confidence": 0.8},
                  "sellable_by_evidence": {"type": "noul", "noul": 0.9},
                  "concentration_is_exit_risk": {"type": "noul", "noul": 0.1},
                  "dev_still_loaded": {"type": "noul", "noul": 0.1}},
    "social": {"account_is_the_project": {"type": "noul", "noul": 0.95},
               "audience_is_real": {"type": "noul", "noul": 0.8},
               "recycled_account": {"type": "noul", "noul": 0.05},
               "effort": {"type": "score", "score": 2.4}},
}


def fresh_book(monkeypatch, tmp_path):
    """book.py with its own empty database."""
    import sqlite3

    import book
    db = sqlite3.connect(str(tmp_path / "desk.db"), check_same_thread=False)
    db.executescript("CREATE TABLE position(id INTEGER PRIMARY KEY CHECK (id = 1), ticker TEXT, addr TEXT, "
                     "net INT, opened_at REAL); CREATE TABLE bench(tid TEXT PRIMARY KEY, reason TEXT, until REAL);")
    monkeypatch.setattr(book, "DB", db)
    return book


def ns(**kw):
    return types.SimpleNamespace(**kw)
