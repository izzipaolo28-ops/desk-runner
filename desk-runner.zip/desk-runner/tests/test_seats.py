import base64
import time

import pytest
from helpers import Net, Resp, fresh_book
from test_wallet import make_tx, new_secret64

import seats as st
import solana_wallet as sw
from jupiter import WSOL, JupiterError

MINT = "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"


class FakeJup:
    """Quotes at a fixed price: 1 SOL = $150; the token at $0.001 with 6 decimals, minus `impact`."""

    def __init__(self, kp=None, impact=0.01, execute=None, sell_price=0.001):
        self.kp, self.impact, self.execute_result, self.sell_price = kp, impact, execute, sell_price
        self.orders, self.executed = [], []

    def sol_usd(self):
        return 150.0

    def order(self, inp, out, amount, taker=None):
        self.orders.append((inp, out, amount, taker))
        if inp == WSOL:
            usd = amount / 1e9 * 150.0
            out_amount = int(usd / 0.001 * (1 - self.impact) * 1e6)
        else:
            usd = amount / 1e6 * self.sell_price
            out_amount = int(usd / 150.0 * 1e9)
        q = {"outAmount": str(out_amount), "inAmount": str(amount), "requestId": f"req{len(self.orders)}"}
        if taker:
            q["transaction"] = make_tx([self.kp.public])[0]
        return q

    def execute(self, signed, request_id):
        self.executed.append((signed, request_id))
        if isinstance(self.execute_result, Exception):
            raise self.execute_result
        return self.execute_result or {"status": "Success", "signature": "SIG", "totalInputAmount": str(self.orders[-1][2]),
                                       "totalOutputAmount": str(self._last_out())}

    def _last_out(self):
        inp, out, amount, _ = self.orders[-1]
        if inp == WSOL:
            return int(amount / 1e9 * 150.0 / 0.001 * (1 - self.impact) * 1e6)
        return int(amount / 1e6 * self.sell_price / 150.0 * 1e9)


class FakeRPC:
    def __init__(self, lamports=2 * 10**9, tokens=0):
        self.lamports, self.tokens = lamports, tokens

    def sol_lamports(self, owner):
        return self.lamports

    def token_balance(self, owner, mint):
        return self.tokens, 6


def order(**kw):
    o = {"order_id": "2026-10-11T10:15:00Z", "model": "jev-1.13.0", "size_factor": 1.0,
         "token": {"ticker": "GOOD", "address": MINT, "network_id": 1399811149, "chain": "solana"},
         "facts": {"liquidity_usd": 50_000.0, "price_usd": 0.001, "decimals": 6, "mcap_usd": 400_000.0, "age_minutes": 60}}
    o.update(kw)
    return o


def make(tmp_path, monkeypatch, live=False, **jkw):
    book = fresh_book(monkeypatch, tmp_path)
    monkeypatch.setattr(st, "book", book)
    env = {"LIVE_MODE": "true" if live else "false", "PAPER_BANK_USD": "1000", "MIN_TICKET_USD": "5",
           "RISK_POLL_SECONDS": "300"}
    cfg = st.Config(env)
    kp = sw.Keypair(new_secret64()) if live else None
    jup = FakeJup(kp, **jkw)
    rpc = FakeRPC()
    s = st.Seats(cfg, jup, rpc, kp, st.State(str(tmp_path / "state.json")))
    return s, jup, rpc, book


# ---- RISK's rule ----
def test_old_tokens_use_exactly_the_desk_rule():
    ratio, window = st.volume_ratio({"h6": 1000, "h24": 40_000}, 30 * 60)
    assert window == "h6" and ratio == pytest.approx(1000 / (40_000 / 4))


def test_young_tokens_are_no_longer_stuck_at_four():
    # 3 hours old, volume died in the last hour: h6 == h24 (the old rule reads 4 and never closes)
    ratio, window = st.volume_ratio({"m5": 0, "h1": 50, "h6": 30_000, "h24": 30_000}, 180)
    assert window == "h1" and ratio == pytest.approx(50 / (30_000 / 3)) and ratio < 0.20
    ratio, window = st.volume_ratio({"m5": 10, "h1": 900, "h24": 900}, 45)      # under 2 h: 5-minute window
    assert window == "m5" and ratio == pytest.approx(10 / (900 * (5 / 60) / 0.75))


@pytest.mark.parametrize("vol, age", [({"h6": 1}, 600), ({"h6": 1, "h24": None}, 1600), ({"h6": 1, "h24": 5}, None)])
def test_unknown_volume_or_age_is_not_a_ratio(vol, age):
    assert st.volume_ratio(vol, age)[0] is None


# ---- SIZE ----
def test_size_is_capped_by_bank_share_and_pool(tmp_path, monkeypatch):
    s, *_ = make(tmp_path, monkeypatch)
    assert s.size(order(), 1000) == (60.0, None)                          # 6% of $1,000
    assert s.size(order(facts={"liquidity_usd": 1000.0}), 1000) == (20.0, None)    # 2% of a $1,000 pool
    assert s.size(order(size_factor=0.24), 1000) == (14.4, None)          # dark + no X
    assert s.size(order(), 50)[0] == 0                                     # $3 ticket under the $5 floor
    assert s.size(order(facts={}), 1000) == (0.0, "pool liquidity unknown")
    assert s.size(order(), None) == (0.0, "no bank figure")


# ---- FILLS, paper ----
def test_paper_buy_uses_a_real_quote_and_sends_nothing(tmp_path, monkeypatch):
    s, jup, rpc, book = make(tmp_path, monkeypatch)
    pos = s.buy(order(), 60.0)
    assert jup.orders[0][3] is None and jup.executed == []                # no taker: quote only
    assert pos["mode"] == "paper" and pos["cost_usd"] == 60.0 and pos["impact_pct"] == pytest.approx(1.0, abs=0.01)
    assert s.bank() == 940.0                                               # paper cash net of the open position


def test_impact_over_the_limit_buys_nothing(tmp_path, monkeypatch):
    s, jup, *_ = make(tmp_path, monkeypatch, impact=0.05)
    with pytest.raises(RuntimeError, match="price impact 5.00% is at or over the 3% limit"):
        s.buy(order(), 60.0)


@pytest.mark.parametrize("facts", [{"price_usd": None, "decimals": 6}, {"price_usd": 0.001, "decimals": None}])
def test_unknown_price_or_decimals_buys_nothing(tmp_path, monkeypatch, facts):
    s, jup, *_ = make(tmp_path, monkeypatch)
    with pytest.raises(RuntimeError, match="unknown"):
        s.buy(order(facts={"liquidity_usd": 50_000.0, **facts}), 60.0)
    assert jup.orders == []


def test_other_chains_are_never_sent_to_jupiter(tmp_path, monkeypatch):
    s, jup, *_ = make(tmp_path, monkeypatch)
    with pytest.raises(RuntimeError, match="Solana only"):
        s.buy(order(token={"ticker": "X", "address": "0x" + "ab" * 20, "network_id": 56, "chain": "bsc"}), 60.0)


# ---- FILLS, live ----
def test_live_buy_signs_with_the_bot_and_reads_the_fill(tmp_path, monkeypatch):
    s, jup, rpc, book = make(tmp_path, monkeypatch, live=True)
    pos = s.buy(order(), 60.0)
    inp, out, lamports, taker = jup.orders[0]
    assert taker == s.kp.address and lamports == int(60 / 150 * 1e9)
    signed, req = jup.executed[0]
    raw = base64.b64decode(signed)
    assert raw[1:65] != b"\x00" * 64 and req == "req1"                    # our signature is in
    assert pos["mode"] == "live" and pos["signature"] == "SIG" and pos["tokens_raw"] > 0


def test_live_buy_refuses_without_enough_sol(tmp_path, monkeypatch):
    s, jup, rpc, book = make(tmp_path, monkeypatch, live=True)
    rpc.lamports = 10**8                                                    # 0.1 SOL
    with pytest.raises(RuntimeError, match="wallet holds"):
        s.buy(order(), 60.0)
    assert jup.orders == []


def test_definite_failure_clears_and_unknown_outcome_waits_for_risk(tmp_path, monkeypatch):
    s, jup, rpc, book = make(tmp_path, monkeypatch, live=True, execute=JupiterError("execute failed", code=-1))
    with pytest.raises(RuntimeError, match="not filled"):
        s.buy(order(), 60.0)
    assert s.state.data["position"] is None
    import requests
    jup.execute_result = requests.Timeout("read timed out")
    with pytest.raises(RuntimeError, match="outcome unknown"):
        s.buy(order(), 60.0)
    assert s.state.data["position"]["status"] == "unconfirmed"
    book.take({"token": {"ticker": "GOOD", "address": MINT, "network_id": 1399811149}})
    rpc.tokens = 59_400_000_000
    s.risk_poll()                                                          # RISK reads the wallet: it landed
    assert s.state.data["position"]["status"] == "open" and s.state.data["position"]["cost_usd"] is None


def test_send_to_seats_releases_the_book_when_nothing_fills(tmp_path, monkeypatch):
    s, jup, rpc, book = make(tmp_path, monkeypatch, impact=0.2)
    book.take({"token": {"ticker": "GOOD", "address": MINT, "network_id": 1399811149}})
    assert s.send_to_seats(order(), 1000) is None
    assert book.held() is None and "price impact" in s.state.data["agents"]["fills"]["line"]


# ---- RISK ----
def dex_pair(h6=2000, h24=40_000, age_min=30 * 60, price=0.001, m5=None, h1=None):
    return [{"chainId": "solana", "baseToken": {"address": MINT}, "liquidity": {"usd": 50_000}, "priceUsd": str(price),
             "pairCreatedAt": int((time.time() - age_min * 60) * 1000),
             "volume": {"m5": m5, "h1": h1, "h6": h6, "h24": h24}}]


def holding(s, book):
    pos = s.buy(order(), 60.0)
    book.take({"token": {"ticker": "GOOD", "address": MINT, "network_id": 1399811149}})
    return pos


def test_risk_holds_then_closes_on_the_volume_rule_and_frees_the_book(tmp_path, monkeypatch):
    s, jup, rpc, book = make(tmp_path, monkeypatch, sell_price=0.0012)
    net = Net(monkeypatch)
    holding(s, book)
    net.get_routes["/tokens/v1/solana/"] = Resp(dex_pair(h6=5000))       # ratio 0.5: hold
    assert s.risk_poll() is None and book.held() is not None
    assert s.state.data["position"]["last_ratio"] == pytest.approx(0.5)
    net.get_routes["/tokens/v1/solana/"] = Resp(dex_pair(h6=1000))       # ratio 0.1: close
    trade = s.risk_poll()
    assert trade["reason"].startswith("volume ratio 0.10") and book.held() is None
    assert trade["pnl_usd"] == pytest.approx(60 * 0.99 * 1.2 - 60, abs=0.05)
    assert s.state.data["position"] is None and "1W 0L" == s.state.data["agents"]["risk"]["label"]


def test_no_answer_twice_then_close_anyway(tmp_path, monkeypatch):
    s, jup, rpc, book = make(tmp_path, monkeypatch)
    net = Net(monkeypatch)
    holding(s, book)
    net.get_routes["/tokens/v1/solana/"] = Resp(None, 500)
    assert s.risk_poll() is None and s.risk_poll() is None
    trade = s.risk_poll()
    assert "three times running" in trade["reason"] and book.held() is None


def test_stop_loss_only_when_set(tmp_path, monkeypatch):
    s, jup, rpc, book = make(tmp_path, monkeypatch, sell_price=0.0005)
    net = Net(monkeypatch)
    holding(s, book)
    net.get_routes["/tokens/v1/solana/"] = Resp(dex_pair(h6=5000, price=0.0005))
    assert s.risk_poll() is None                                           # off by default: the volume rule decides
    s.cfg.stop_loss_pct = 30
    trade = s.risk_poll()
    assert trade["reason"].startswith("stop-loss") and trade["pnl_usd"] < 0


def test_live_close_sells_what_the_wallet_really_holds(tmp_path, monkeypatch):
    s, jup, rpc, book = make(tmp_path, monkeypatch, live=True)
    net = Net(monkeypatch)
    holding(s, book)
    rpc.tokens = 12_345_000
    net.get_routes["/tokens/v1/solana/"] = Resp(dex_pair(h6=100))
    trade = s.risk_poll()
    sell = jup.orders[-1]
    assert sell[0] == MINT and sell[1] == WSOL and sell[2] == 12_345_000 and sell[3] == s.kp.address
    assert trade["mode"] == "live" and book.held() is None


def test_failed_close_keeps_holding_and_retries(tmp_path, monkeypatch):
    s, jup, rpc, book = make(tmp_path, monkeypatch, live=True)
    net = Net(monkeypatch)
    holding(s, book)
    rpc.tokens = 1000
    jup.execute_result = JupiterError("execute failed", code=-1)
    net.get_routes["/tokens/v1/solana/"] = Resp(dex_pair(h6=100))
    assert s.risk_poll() is None and book.held() is not None
    assert "close of GOOD failed" in s.state.data["agents"]["risk"]["line"]


def test_daily_loss_limit_pauses_new_entries(tmp_path, monkeypatch):
    s, *_ = make(tmp_path, monkeypatch)
    assert s.daily_guard(1000) is True
    s.state.data["realized_today"] = -199.0
    assert s.daily_guard(1000) is True
    s.state.data["realized_today"] = -200.0
    assert s.daily_guard(1000) is False and s.state.data["paused"] and "daily loss limit" in s.state.data["pause_reason"]


def test_live_mode_needs_a_wallet_and_strict_values(tmp_path):
    with pytest.raises(ValueError):
        st.Config({"LIVE_MODE": "yes"})
    with pytest.raises(ValueError):
        st.Seats(st.Config({"LIVE_MODE": "true"}), None, None, None, st.State(str(tmp_path / "s.json")))


def test_paper_close_waits_for_the_sol_price_instead_of_booking_zero(tmp_path, monkeypatch):
    s, jup, rpc, book = make(tmp_path, monkeypatch, sell_price=0.0012)
    net = Net(monkeypatch)
    holding(s, book)
    net.get_routes["/tokens/v1/solana/"] = Resp(dex_pair(h6=1000))       # ratio 0.1: close...
    monkeypatch.setattr(jup, "sol_usd", lambda: (_ for _ in ()).throw(RuntimeError("price down")))
    assert s.risk_poll() is None and s.state.data["position"] is not None and s.state.data["trades"] == []
    monkeypatch.setattr(jup, "sol_usd", lambda: 150.0)                     # ...when the price is back
    trade = s.risk_poll()
    assert trade["pnl_usd"] == pytest.approx(60 * 0.99 * 1.2 - 60, abs=0.05) and trade["proceeds_sol"] > 0
