"""The whole loop on paper, end to end: universe -> public list -> cuts -> dossier (with Solana RPC) -> the desk's
real question sets (fake answers) -> pick -> SIZE -> FILLS (real-shaped Jupiter quote) -> RISK -> close.
Then the dashboard server and the page itself."""
import copy
import json
import os
import threading
import time
import urllib.error
import urllib.request

import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
from helpers import GOOD, FakeDesk, Net, Resp, fresh_book
from test_seats import FakeJup, FakeRPC

import runner as rn
import seats as st
from solana_wallet import b58encode

SPL = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"


def wallet():
    return b58encode(Ed25519PrivateKey.generate().public_key().public_bytes(Encoding.Raw, PublicFormat.Raw))


def program_owned():
    import collect
    for _ in range(200):
        a = b58encode(os.urandom(32))
        if collect.on_curve(a) is False:
            return a
    raise AssertionError


def pair(addr, h6=20_000, h24=90_000, price="0.001"):
    return {"chainId": "solana", "baseToken": {"address": addr, "symbol": "TOK" + addr[:2]}, "priceUsd": price,
            "liquidity": {"usd": 50_000}, "marketCap": 500_000, "fdv": 900_000, "volume": {"m5": 300, "h1": 4000, "h6": h6, "h24": h24},
            "priceChange": {"m5": 2, "h1": 10, "h24": 40}, "pairCreatedAt": int((time.time() - 26 * 3600) * 1000),
            "txns": {"h1": {"buys": 60, "sells": 20}, "h6": {"buys": 300, "sells": 150}, "h24": {"buys": 500, "sells": 300}}}


@pytest.fixture
def desk(monkeypatch, tmp_path):
    net = Net(monkeypatch)
    book = fresh_book(monkeypatch, tmp_path)
    for mod in (rn, st):
        monkeypatch.setattr(mod, "book", book)
    import main
    monkeypatch.setattr(main, "book", book)
    monkeypatch.setattr(main, "JUDGE_LOG", str(tmp_path / "judge_log.jsonl"))
    toks = [b58encode(os.urandom(32)) for _ in range(2)]
    net.get_routes["/networks/solana/new_pools"] = Resp({"data": [
        {"relationships": {"base_token": {"data": {"id": f"solana_{t}"}}}} for t in toks]})
    net.get_routes["/tokens/v1/solana/"] = Resp([pair(t) for t in toks])
    for t in toks:
        net.get_routes[f"/tokens/{t}/info"] = Resp({"data": {"attributes": {
            "holders": {"count": 900, "distribution_percentage": {"top_10": "30"}}, "is_honeypot": "unknown",
            "mint_authority": "no", "freeze_authority": "no", "twitter_handle": None,
            "developer_holding_percentage": "1.5"}}})
    pool, whale = program_owned(), wallet()
    net.rpc = {
        "getAccountInfo": Resp({"result": {"value": {"owner": SPL, "data": {"parsed": {"type": "mint", "info": {
            "mintAuthority": None, "freezeAuthority": None, "supply": "1000000000000", "decimals": 6, "isInitialized": True}}}}}}),
        "getTokenLargestAccounts": Resp({"result": {"value": [{"address": b58encode(os.urandom(32)), "amount": "600000000000"},
                                                             {"address": b58encode(os.urandom(32)), "amount": "20000000000"}]}}),
        "getMultipleAccounts": Resp({"result": {"value": [{"data": {"parsed": {"info": {"owner": pool}}}},
                                                          {"data": {"parsed": {"info": {"owner": whale}}}}]}}),
    }
    answers = copy.deepcopy(GOOD) | {"pick": {
        "best": {"type": "choice", "choice": "c2", "confidence": 0.8, "probabilities": {"c1": 0.2, "c2": 0.8}},
        "worth_trading_at_all": {"type": "noul", "noul": 0.9}}}
    judge = FakeDesk(answers)
    cfg = st.Config({"LIVE_MODE": "false", "PAPER_BANK_USD": "1000", "RISK_POLL_SECONDS": "300"})
    state = st.State(str(tmp_path / "state.json"))
    seats = st.Seats(cfg, FakeJup(sell_price=0.0011), FakeRPC(), None, state)
    clock = [1_000_000.0]
    from public_list import PublicList
    r = rn.Runner(cfg, seats, state, judge, PublicList(), clock=lambda: clock[0])
    return r, net, judge, toks, clock, book


def test_paper_loop_scans_buys_holds_and_closes(desk):
    r, net, judge, toks, clock, book = desk
    assert r.tick() == "cycle: order"
    sets = [s for s, _ in judge.calls]
    assert sets == ["market", "solana", "market", "solana", "pick"]
    pos = r.state.data["position"]
    assert pos["mint"] == toks[1] and pos["mode"] == "paper" and pos["cost_usd"] == pytest.approx(36.0)   # 6% x 0.6 (no X)
    assert book.held()["ticker"] == "TOK" + toks[1][:2]
    assert r.tick() == "holding"                                          # no scan while held, RISK waits its turn
    clock[0] += 301
    assert r.tick() == "risk: holding"                                    # ratio 20,000 / (90,000/4) = 0.89
    net.get_routes["/tokens/v1/solana/"] = Resp([pair(toks[1], h6=2000, price="0.0011")])   # ratio 0.09
    clock[0] += 301
    assert r.tick() == "risk: closed"
    (trade,) = r.state.data["trades"]
    assert trade["pnl_usd"] == pytest.approx(36 * 0.99 * 1.1 - 36, abs=0.05) and book.held() is None
    a = r.state.data["agents"]
    for seat in ("chief", "scan", "vet", "size", "fills", "risk", "crawler"):
        assert a[seat]["line"], seat
    assert a["vet"]["line"].startswith("solana: authority risk renounced")
    assert len(r.state.data["equity"]) >= 2 and all(v is not None for _, v in r.state.data["equity"])


def test_paused_desk_does_not_scan_but_risk_still_runs(desk):
    r, net, judge, toks, clock, book = desk
    r.set_paused(True, "test")
    assert r.tick() == "paused" and judge.calls == []
    r.set_paused(False)
    assert r.tick() == "cycle: order"
    r.set_paused(True, "test")
    clock[0] += 301
    assert r.tick().startswith("risk")                                    # RISK keeps managing the open position


def test_missing_developer_figure_cuts_the_ticket_not_the_token(desk):
    r, net, judge, toks, clock, book = desk
    for t in toks:
        info = net.get_routes[f"/tokens/{t}/info"].body["data"]["attributes"]
        info.pop("developer_holding_percentage")
    assert r.tick() == "cycle: order"
    pos = r.state.data["position"]
    assert pos["size_factor"] == 0.24 and pos["cost_usd"] == pytest.approx(14.4)   # 6% x 0.4 (no evidence) x 0.6 (no X)


def test_cycle_waits_its_interval(desk):
    r, net, judge, toks, clock, book = desk
    judge.answers["pick"]["worth_trading_at_all"]["noul"] = 0.1
    assert r.tick() == "cycle: no order"
    assert r.tick() == "waiting"
    assert "not a day" in r.state.data["agents"]["chief"]["line"]


def serve(r, token="t" * 32):
    from http.server import ThreadingHTTPServer
    httpd = ThreadingHTTPServer(("127.0.0.1", 0), rn.make_handler(r, token))
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd, f"http://127.0.0.1:{httpd.server_address[1]}"


def post(url, token=None):
    req = urllib.request.Request(url, data=b"", method="POST", headers={"X-Admin-Token": token} if token else {})
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, json.loads(resp.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())


def test_status_and_admin_endpoints(desk):
    r, *_ = desk
    r.tick()
    httpd, base = serve(r)
    try:
        with urllib.request.urlopen(base + "/api/status") as resp:
            s = json.loads(resp.read())
        assert s["mode"] == "paper" and s["position"]["mode"] == "paper" and s["thresholds"]["HARD"]["max_top_wallet"] == 0.05
        assert "BOT_WALLET_KEY" not in json.dumps(s) and s["wallet"] is None
        assert post(base + "/api/pause")[0] == 401 and post(base + "/api/pause", "wrong")[0] == 401
        assert post(base + "/api/pause", "t" * 32) == (200, {"paused": True})
        assert post(base + "/api/resume", "t" * 32) == (200, {"paused": False})
        with urllib.request.urlopen(base + "/") as resp:
            assert b"DESK FLOOR" in resp.read()
    finally:
        httpd.shutdown()


def test_no_admin_token_means_nobody_can_pause(desk):
    r, *_ = desk
    httpd, base = serve(r, token="")
    try:
        assert post(base + "/api/pause", "")[0] == 401 and post(base + "/api/pause", "anything")[0] == 401
    finally:
        httpd.shutdown()


def test_dashboard_renders_real_status_on_a_phone(desk):
    from playwright.sync_api import sync_playwright
    r, net, judge, toks, clock, book = desk
    r.tick()
    clock[0] += 301
    r.tick()
    httpd, base = serve(r)
    shots = os.environ.get("SHOTS")
    try:
        with sync_playwright() as pw:
            b = pw.chromium.launch()
            page = b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True).new_page()
            errors = []
            page.on("pageerror", lambda e: errors.append(str(e)))
            page.goto(base + "/")
            page.wait_for_function("document.getElementById('balanceNow').textContent.startsWith('$')")
            text = page.inner_text("body")
            assert not errors, errors
            assert "undefined" not in text and "NaN" not in text and "PAPER" in text and "HOLDING" in text
            assert "authority risk renounced" in text and "free_kill" in text
            assert page.evaluate("document.documentElement.scrollWidth <= window.innerWidth")
            if shots:
                page.screenshot(path=os.path.join(shots, "floor_phone.png"), full_page=True)
                wide = b.new_context(viewport={"width": 1200, "height": 900}).new_page()
                wide.goto(base + "/")
                wide.wait_for_function("document.getElementById('balanceNow').textContent.startsWith('$')")
                wide.screenshot(path=os.path.join(shots, "floor_wide.png"), full_page=True)
            b.close()
    finally:
        httpd.shutdown()


# ---------- startup: a wrong variable shows on the page instead of crash-looping the service ----------
@pytest.mark.parametrize("env, says", [
    ({"LIVE_MODE": "yes"}, "LIVE_MODE must be exactly true or false"),
    ({"LIVE_MODE": "true"}, "LIVE_MODE=true needs BOT_WALLET_KEY"),
    ({"LIVE_MODE": "false", "BOT_WALLET_KEY": "not a key 0OIl"}, "BOT_WALLET_KEY is not a valid Solana private key"),
    ({"LIVE_MODE": "false", "STOP_LOSS_PCT": "15%"}, "STOP_LOSS_PCT must be a number between 0 and 100"),
    ({"LIVE_MODE": "false", "PAPER_BANK_USD": "-5"}, "PAPER_BANK_USD must be a number at least 1"),
    ({"LIVE_MODE": "true", "RAILWAY_PROJECT_ID": "p"}, "needs a volume first"),
])
def test_bad_variables_stop_the_desk_and_say_which(env, says):
    r = rn.safe_build(env)
    assert isinstance(r, rn.Stopped) and says in r.reason and r.tick() == "stopped"
    s = r.status()
    assert s["mode"] == "stopped" and s["paused"] and says in s["errors"][0]["text"]
    for v in env.values():
        if len(v) > 4:
            assert v not in json.dumps(s)                                 # never echoes a value back


def test_good_variables_build_a_paper_desk(tmp_path):
    r = rn.safe_build({"LIVE_MODE": "false", "STOP_LOSS_PCT": "15", "RAILWAY_PROJECT_ID": "p"})
    assert isinstance(r, rn.Runner) and r.cfg.stop_loss_pct == 15 and not r.cfg.live


def test_short_admin_token_cannot_pause(desk):
    r, *_ = desk
    httpd, base = serve(r, token="short")
    try:
        assert post(base + "/api/pause", "short")[0] == 401
    finally:
        httpd.shutdown()


def test_stopped_desk_page_says_why_on_a_phone():
    from playwright.sync_api import sync_playwright
    httpd, base = serve(rn.Stopped("LIVE_MODE must be exactly true or false"))
    try:
        with sync_playwright() as pw:
            b = pw.chromium.launch()
            page = b.new_context(viewport={"width": 390, "height": 844}, is_mobile=True).new_page()
            errors = []
            page.on("pageerror", lambda e: errors.append(str(e)))
            page.goto(base + "/")
            page.wait_for_function("document.getElementById('mode').textContent === 'STOPPED'")
            text = page.inner_text("body")
            assert not errors and "LIVE_MODE must be exactly true or false" in text
            assert "undefined" not in text and "NaN" not in text
            b.close()
    finally:
        httpd.shutdown()
