import base64
import json

import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.serialization import Encoding, NoEncryption, PrivateFormat, PublicFormat
import helpers  # noqa: F401  (paths)

import solana_wallet as sw


def new_secret64():
    k = Ed25519PrivateKey.generate()
    seed = k.private_bytes(Encoding.Raw, PrivateFormat.Raw, NoEncryption())
    return seed + k.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)


def test_phantom_base58_and_cli_json_keys_load():
    raw = new_secret64()
    a = sw.Keypair.from_env(sw.b58encode(raw))
    b = sw.Keypair.from_env(json.dumps(list(raw)))
    assert a.address == b.address == sw.b58encode(raw[32:])
    assert sw.b58encode(raw) not in repr(a) and a.address in repr(a)


@pytest.mark.parametrize("bad", ["", "not base58 0OIl", "[1,2,3]", sw.b58encode(b"\x01" * 64)])
def test_bad_keys_are_refused_without_echoing_them(bad):
    with pytest.raises(sw.WalletKeyError) as err:
        sw.Keypair.from_env(bad)
    assert (bad not in str(err.value)) or not bad


def compact(n):
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        out.append(b | (0x80 if n else 0))
        if not n:
            return bytes(out)


def make_tx(signers, version0=True, extra_keys=2):
    """A minimal transaction: header + keys + blockhash + no instructions. Signature slots zeroed."""
    keys = list(signers) + [bytes([9]) * 32] * extra_keys
    msg = (b"\x80" if version0 else b"") + bytes([len(signers), 0, 1]) + compact(len(keys)) + b"".join(keys) \
        + b"\x11" * 32 + compact(0) + (compact(0) if version0 else b"")
    return base64.b64encode(compact(len(signers)) + b"\x00" * 64 * len(signers) + msg).decode(), msg


@pytest.mark.parametrize("version0", [True, False])
@pytest.mark.parametrize("slot", [0, 1])
def test_signature_lands_in_our_slot_and_verifies(version0, slot):
    kp = sw.Keypair(new_secret64())
    other = Ed25519PrivateKey.generate().public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
    signers = [kp.public, other] if slot == 0 else [other, kp.public]
    tx, msg = make_tx(signers, version0)
    raw = base64.b64decode(sw.sign_transaction(tx, kp))
    n, off = sw._read_compact(raw, 0)
    sig = raw[off + 64 * slot: off + 64 * slot + 64]
    Ed25519PublicKey.from_public_bytes(kp.public).verify(sig, msg)          # raises if wrong
    untouched = raw[off + 64 * (1 - slot): off + 64 * (1 - slot) + 64]
    assert untouched == b"\x00" * 64 and raw[off + 128:] == msg              # market maker's slot left alone


def test_refuses_a_transaction_not_meant_for_the_bot():
    kp = sw.Keypair(new_secret64())
    tx, _ = make_tx([bytes([7]) * 32])
    with pytest.raises(ValueError):
        sw.sign_transaction(tx, kp)


def test_refuses_versions_it_cannot_sign():
    kp = sw.Keypair(new_secret64())
    tx, msg = make_tx([kp.public])
    raw = bytearray(base64.b64decode(tx))
    raw[1 + 64] = 0x81                                                      # version 1
    with pytest.raises(ValueError):
        sw.sign_transaction(base64.b64encode(bytes(raw)).decode(), kp)


def test_compact_u16_round_trip():
    for n in (0, 1, 127, 128, 255, 16383, 16384, 65535):
        assert sw._read_compact(compact(n), 0) == (n, len(compact(n)))


class FakeSession:
    def __init__(self, answers):
        self.answers, self.urls = answers, []

    def post(self, url, json=None, timeout=None):
        self.urls.append(url)
        a = self.answers.pop(0)
        if isinstance(a, Exception):
            raise a
        return type("R", (), {"json": lambda self: a})()


def test_rpc_falls_through_to_the_next_endpoint_and_reads_balances():
    import requests
    s = FakeSession([requests.ConnectionError("down"), {"error": {"code": -1}},
                     {"result": {"value": 2_500_000_000}}])
    rpc = sw.RPC(["https://my.rpc/"], session=s)
    assert rpc.sol_lamports("W") == 2_500_000_000 and len(s.urls) == 3
    s = FakeSession([{"result": {"value": [
        {"account": {"data": {"parsed": {"info": {"tokenAmount": {"amount": "1500", "decimals": 6}}}}}},
        {"account": {"data": {"parsed": {"info": {"tokenAmount": {"amount": "500", "decimals": 6}}}}}}]}}])
    assert sw.RPC(session=s).token_balance("W", "M") == (2000, 6)
