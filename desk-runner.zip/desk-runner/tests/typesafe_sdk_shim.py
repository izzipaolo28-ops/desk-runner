"""Stand-in for typesafe_sdk's question classes, so the desk's questions.py can be loaded and checked
without the SDK installed. Tests only; the desk itself imports the real SDK."""
from dataclasses import dataclass, field


@dataclass
class _Question:
    instructions: str
    criteria: object = None

    def wire(self) -> dict:
        out = {"type": type(self).__name__.lower(), "instructions": self.instructions}
        if self.criteria is not None:
            out["criteria"] = self.criteria
        return out


class Choice(_Question):
    pass


class Score(_Question):
    pass


class Noul(_Question):
    pass
